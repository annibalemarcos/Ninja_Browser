// Inspector Ninja Browser - Web Edition
// Adaptação para iframe (sem Electron). Funciona com sites same-origin
// ou que não bloqueiem iframe via X-Frame-Options / CSP frame-ancestors.

const urlInput = document.getElementById('urlInput');
const goBtn = document.getElementById('goBtn');
const loadHtmlBtn = document.getElementById('loadHtmlBtn');
const inspectorSidebar = document.getElementById('inspectorSidebar');
const closeInspector = document.getElementById('closeInspector');
const inspectorContent = document.getElementById('inspectorContent');
const consoleContent = document.getElementById('consoleContent');
const clearConsole = document.getElementById('clearConsole');
const iframe = document.getElementById('browserFrame');
const elementInspectorBtn = document.getElementById('elementInspectorBtn');
const toggleConsoleBtn = document.getElementById('toggleConsoleBtn');
const rulerBtn = document.getElementById('rulerBtn');
const rulerPanel = document.getElementById('rulerPanel');
const rulerPanelBody = document.getElementById('rulerPanelBody');
const closeRulerPanel = document.getElementById('closeRulerPanel');
const corsBanner = document.getElementById('corsBanner');
const pasteHtmlHint = document.getElementById('pasteHtmlHint');

let lastAllElementsResult = null;
let rulerActive = false;
let rulerFirstElement = null;

// ===== NAVIGATION =====
function navigate(input) {
  if (!input || input.trim() === '') return;
  let url = input.trim();
  if (!url.match(/^https?:\/\//i) && !url.startsWith('about:')) {
    if (url.includes(' ') || !url.includes('.')) {
      url = `https://www.google.com/search?q=${encodeURIComponent(url)}`;
    } else {
      url = 'https://' + url;
    }
  }
  logToConsole('Carregando: ' + url, 'info');
  iframe.src = url;
  urlInput.value = url;
}

goBtn.addEventListener('click', () => navigate(urlInput.value));
urlInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') navigate(urlInput.value);
});

// ===== PASTE HTML MODE =====
function openPasteHtmlModal() {
  let modal = document.getElementById('pasteHtmlModal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'pasteHtmlModal';
    modal.className = 'paste-html-modal';
    modal.innerHTML = `
      <div class="paste-html-modal-content">
        <h3>📋 Colar HTML para inspecionar</h3>
        <p style="color: var(--text-secondary); font-size: 12px;">
          Cole aqui o HTML completo de uma página (ex.: View Source). Ele será carregado no iframe e poderá ser inspecionado livremente, sem restrições de CORS.
        </p>
        <textarea id="pasteHtmlTextarea" placeholder="<!DOCTYPE html>&#10;<html>&#10;..."></textarea>
        <div class="paste-html-modal-actions">
          <button class="ruler-action-btn" id="pasteHtmlCancel">Cancelar</button>
          <button class="ruler-action-btn copy" id="pasteHtmlLoad">Carregar HTML</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.classList.remove('open');
    });
    document.getElementById('pasteHtmlCancel').addEventListener('click', () => modal.classList.remove('open'));
    document.getElementById('pasteHtmlLoad').addEventListener('click', () => {
      const html = document.getElementById('pasteHtmlTextarea').value;
      if (!html.trim()) return;
      const blob = new Blob([html], { type: 'text/html' });
      iframe.src = URL.createObjectURL(blob);
      urlInput.value = '(HTML colado)';
      modal.classList.remove('open');
      logToConsole('HTML colado carregado no iframe', 'info');
    });
  }
  modal.classList.add('open');
}

loadHtmlBtn.addEventListener('click', openPasteHtmlModal);
pasteHtmlHint.addEventListener('click', openPasteHtmlModal);

// ===== IFRAME ACCESS (com tratamento de erro CORS) =====
function getIframeDoc() {
  try {
    return iframe.contentDocument || iframe.contentWindow.document;
  } catch (err) {
    logToConsole('⚠️ Não foi possível acessar o conteúdo do iframe: ' + err.message + ' (provavelmente CORS / X-Frame-Options).', 'error');
    return null;
  }
}

iframe.addEventListener('load', () => {
  logToConsole('Iframe carregado', 'info');
  const doc = getIframeDoc();
  if (!doc) return;
  // Registra contextmenu dentro do iframe para inspeção via clique direito
  try {
    doc.addEventListener('contextmenu', handleIframeContextMenu, true);
    doc.addEventListener('click', handleIframeClickForRuler, true);
  } catch (err) {
    logToConsole('Não foi possível anexar handlers ao iframe: ' + err.message, 'error');
  }
});

function handleIframeContextMenu(e) {
  if (rulerActive) return; // régua usa click esquerdo
  e.preventDefault();
  const element = e.target;
  const data = collectElementData(element);
  if (data) {
    displayInspectorSidebar(data);
    logToConsole(`Elemento inspecionado: <${data.tagName}>`, 'info');
  }
}

// ===== COLETA DE DADOS DE UM ELEMENTO =====
function getCssPath(element) {
  const path = [];
  while (element && element.nodeType === Node.ELEMENT_NODE) {
    let selector = element.nodeName.toLowerCase();
    if (element.id) { selector += '#' + element.id; path.unshift(selector); break; }
    if (element.className && typeof element.className === 'string') {
      const classes = element.className.trim().split(/\s+/).filter(c => c);
      if (classes.length > 0) selector += '.' + classes.join('.');
    }
    let sibling = element, nth = 1;
    while (sibling.previousElementSibling) {
      sibling = sibling.previousElementSibling;
      if (sibling.nodeName.toLowerCase() === element.nodeName.toLowerCase()) nth++;
    }
    if (nth > 1) selector += `:nth-of-type(${nth})`;
    path.unshift(selector);
    element = element.parentElement;
  }
  return path.join(' > ');
}

function getCssSelector(element) {
  if (element.id) return '#' + element.id;
  return getCssPath(element);
}

function collectElementData(element) {
  if (!element || element.nodeType !== Node.ELEMENT_NODE) return null;
  const classes = (element.className && typeof element.className === 'string')
    ? element.className.trim().split(/\s+/).filter(c => c).join(' ')
    : '';
  const text = (element.innerText || element.textContent || '').trim().substring(0, 500);
  return {
    tagName: element.tagName.toLowerCase(),
    id: element.id || '',
    classes,
    cssPath: getCssPath(element),
    cssSelector: getCssSelector(element),
    innerText: text,
    href: element.href || '',
    src: element.src || '',
    alt: element.alt || '',
    title: element.title || '',
    outerHTML: element.outerHTML.length > 2000 ? element.outerHTML.substring(0, 2000) + '...' : element.outerHTML
  };
}

// ===== INSPETOR INDIVIDUAL =====
function displayInspectorSidebar(data) {
  const copyIcon = `📋`;
  const sections = [];
  sections.push(`
    <div class="copy-option" style="border: 2px solid var(--accent-neon);">
      <div class="copy-option-header">
        <span class="copy-option-label" style="color: var(--accent-neon);">📌 ELEMENTO</span>
      </div>
      <div class="copy-option-value" style="color: var(--accent-neon); font-weight: 600;">
        &lt;${data.tagName}&gt;${data.id ? ' #' + escapeHtml(data.id) : ''}${data.classes ? ' .' + escapeHtml(data.classes.split(' ').join(' .')) : ''}
      </div>
    </div>
  `);
  const addRow = (label, value) => {
    if (!value) return;
    sections.push(`
      <div class="copy-option">
        <div class="copy-option-header">
          <span class="copy-option-label">${label}</span>
          <button class="copy-btn" onclick='copyToClipboardWeb(${JSON.stringify(value)}, this)'>${copyIcon} COPIAR</button>
        </div>
        <div class="copy-option-value">${escapeHtml(value)}</div>
      </div>
    `);
  };
  addRow('🛤️ CSS Path', data.cssPath);
  addRow('🎨 CSS Selector', data.cssSelector);
  addRow('🆔 ID', data.id);
  addRow('✨ Classes', data.classes);
  addRow('🔗 href', data.href);
  addRow('🖼️ src', data.src);
  addRow('🏷️ alt', data.alt);
  addRow('💬 title', data.title);
  addRow('📝 Texto', data.innerText);
  addRow('📦 HTML', data.outerHTML);
  inspectorContent.innerHTML = sections.join('');
  inspectorSidebar.classList.add('open');
}

closeInspector.addEventListener('click', () => inspectorSidebar.classList.remove('open'));

// ===== LISTAR TODOS OS ELEMENTOS =====
elementInspectorBtn.addEventListener('click', handleListAllElements);

function handleListAllElements() {
  const doc = getIframeDoc();
  if (!doc) return;
  elementInspectorBtn.classList.add('loading');
  elementInspectorBtn.disabled = true;
  try {
    const SKIP = new Set(['SCRIPT', 'STYLE', 'META', 'LINK', 'NOSCRIPT', 'HEAD', 'TITLE']);
    const all = doc.querySelectorAll('*');
    const list = [];
    const MAX = 2000;
    for (let i = 0; i < all.length && list.length < MAX; i++) {
      const el = all[i];
      if (SKIP.has(el.tagName)) continue;
      const classes = (el.className && typeof el.className === 'string')
        ? el.className.trim().split(/\s+/).filter(c => c).join(' ') : '';
      const text = (el.innerText || el.textContent || '').trim().replace(/\s+/g, ' ').substring(0, 120);
      list.push({
        tagName: el.tagName.toLowerCase(),
        id: el.id || '',
        classes,
        cssPath: getCssPath(el),
        text,
        outerHTML: el.outerHTML.length > 400 ? el.outerHTML.substring(0, 400) + '...' : el.outerHTML
      });
    }
    const result = {
      total: all.length,
      collected: list.length,
      truncated: all.length > MAX,
      url: (() => { try { return iframe.contentWindow.location.href; } catch { return iframe.src; } })(),
      title: (() => { try { return doc.title; } catch { return ''; } })(),
      elements: list
    };
    lastAllElementsResult = result;
    renderAllElementsList(result);
    inspectorSidebar.classList.add('open');
    logToConsole(`✓ ${result.collected} elementos coletados${result.truncated ? ' (limitado a 2000)' : ''}`, 'info');
  } catch (err) {
    logToConsole('Erro ao coletar elementos: ' + err.message, 'error');
  } finally {
    elementInspectorBtn.classList.remove('loading');
    elementInspectorBtn.disabled = false;
  }
}

function renderAllElementsList(data) {
  const countLabel = `${data.collected}${data.truncated ? ' / ' + data.total : ''}`;
  let html = `
    <div class="all-elements-header">
      <span class="all-elements-header-title">🥷 Todos os Elementos</span>
      <span class="all-elements-count" data-testid="all-elements-count">${countLabel}</span>
    </div>
  `;
  if (data.elements.length === 0) {
    html += `<div class="inspector-empty"><p>Nenhum elemento encontrado.</p></div>`;
  } else {
    data.elements.forEach((el, idx) => {
      const tagDisplay = `&lt;${el.tagName}&gt;` +
        (el.id ? `<span class="el-id"> #${escapeHtml(el.id)}</span>` : '') +
        (el.classes ? `<span class="el-class"> .${escapeHtml(el.classes.split(' ').join(' .'))}</span>` : '');
      html += `
        <div class="element-row" data-testid="element-row-${idx}">
          <div class="element-row-top">
            <div class="element-row-tag">${tagDisplay}</div>
            <span class="element-row-index">#${idx + 1}</span>
          </div>
          <div class="element-row-csspath">
            <span class="element-row-csspath-label">CSS PATH:</span>${escapeHtml(el.cssPath)}
          </div>
          <div class="element-row-actions">
            <button class="copy-btn" data-testid="copy-element-btn-${idx}" onclick="copyElementWeb(${idx}, this)">📋 COPIAR</button>
          </div>
        </div>
      `;
    });
    html += `
      <div class="save-txt-container">
        <button class="save-txt-btn" data-testid="save-txt-btn" onclick="saveAllElementsToTxtWeb(this)">
          💾 Salvar todos os elementos em TXT
        </button>
      </div>
    `;
  }
  inspectorContent.innerHTML = html;
}

function buildElementCopyText(el) {
  const lines = [`<${el.tagName}>`];
  if (el.id) lines.push(`ID: ${el.id}`);
  if (el.classes) lines.push(`Classes: ${el.classes}`);
  lines.push(`CSS Path: ${el.cssPath}`);
  if (el.text) lines.push(`Texto: ${el.text}`);
  if (el.outerHTML) lines.push(`HTML: ${el.outerHTML}`);
  return lines.join('\n');
}

window.copyElementWeb = function(idx, btn) {
  if (!lastAllElementsResult || !lastAllElementsResult.elements[idx]) return;
  const el = lastAllElementsResult.elements[idx];
  navigator.clipboard.writeText(buildElementCopyText(el));
  flashCopied(btn);
  logToConsole(`✓ Elemento #${idx + 1} copiado`, 'info');
};

window.copyToClipboardWeb = function(text, btn) {
  navigator.clipboard.writeText(text);
  flashCopied(btn);
  logToConsole('✓ Copiado para clipboard', 'info');
};

function flashCopied(btn) {
  const original = btn.innerHTML;
  btn.innerHTML = '✓ Copiado!';
  btn.classList.add('copied');
  setTimeout(() => { btn.innerHTML = original; btn.classList.remove('copied'); }, 1800);
}

window.saveAllElementsToTxtWeb = function(btn) {
  if (!lastAllElementsResult) return;
  const data = lastAllElementsResult;
  const now = new Date();
  const sep = '='.repeat(80);
  const sub = '-'.repeat(80);
  const header = [sep, '🥷 INSPECTOR NINJA WEB - EXPORTAÇÃO', sep,
    `URL:     ${data.url}`, `Título:  ${data.title}`,
    `Data:    ${now.toLocaleString()}`,
    `Total:   ${data.collected}${data.truncated ? ' (limitado de ' + data.total + ')' : ''}`,
    sep, ''];
  const body = data.elements.flatMap((el, i) => {
    const lines = [`[#${i + 1}] <${el.tagName}>`];
    if (el.id) lines.push(`  ID:        ${el.id}`);
    if (el.classes) lines.push(`  Classes:   ${el.classes}`);
    lines.push(`  CSS Path:  ${el.cssPath}`);
    if (el.text) lines.push(`  Texto:     ${el.text}`);
    if (el.outerHTML) lines.push(`  HTML:      ${el.outerHTML}`);
    lines.push(sub);
    return lines;
  });
  const content = header.concat(body).join('\n');
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const ts = now.toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const filename = `ninja-elements-${ts}.txt`;
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  const orig = btn.innerHTML;
  btn.innerHTML = '✓ TXT salvo!';
  btn.classList.add('saved');
  setTimeout(() => { btn.innerHTML = orig; btn.classList.remove('saved'); }, 2500);
  logToConsole(`💾 ${data.collected} elementos salvos em ${filename}`, 'info');
};

// ===== RÉGUA =====
rulerBtn.addEventListener('click', () => rulerActive ? deactivateRuler() : activateRuler());
closeRulerPanel.addEventListener('click', deactivateRuler);

function activateRuler() {
  rulerActive = true; rulerFirstElement = null;
  rulerBtn.classList.add('active');
  rulerPanel.classList.add('open');
  rulerPanelBody.innerHTML = `<p class="ruler-instructions">Clique no <strong>1º elemento</strong> no iframe para começar a medir.</p>`;
  logToConsole('📐 Régua ativada — clique no 1º elemento', 'info');
}

function deactivateRuler() {
  rulerActive = false; rulerFirstElement = null;
  rulerBtn.classList.remove('active');
  rulerPanel.classList.remove('open');
  logToConsole('📐 Régua desativada', 'info');
}

function handleIframeClickForRuler(e) {
  if (!rulerActive) return;
  e.preventDefault();
  e.stopPropagation();
  const el = e.target;
  const rect = el.getBoundingClientRect();
  const info = {
    tagName: el.tagName.toLowerCase(),
    id: el.id || '',
    classes: (el.className && typeof el.className === 'string') ? el.className.trim() : '',
    cssPath: getCssPath(el),
    rect: {
      top: rect.top, left: rect.left, right: rect.right, bottom: rect.bottom,
      width: rect.width, height: rect.height,
      centerX: rect.left + rect.width / 2,
      centerY: rect.top + rect.height / 2
    }
  };
  if (!rulerFirstElement) {
    rulerFirstElement = info;
    renderRulerFirstPicked(info);
  } else {
    const m = computeRulerMeasurements(rulerFirstElement, info);
    renderRulerResult(rulerFirstElement, info, m);
    rulerFirstElement = null;
  }
}

function elementSummary(el) {
  const id = el.id ? ` #${el.id}` : '';
  const cls = el.classes ? ` .${el.classes.split(/\s+/).join('.')}` : '';
  return `&lt;${el.tagName}&gt;${escapeHtml(id + cls)}`;
}

function buildRulerCard(el, label, second) {
  const dim = `${Math.round(el.rect.width)} × ${Math.round(el.rect.height)} px @ (${Math.round(el.rect.left)}, ${Math.round(el.rect.top)})`;
  return `<div class="ruler-element-card${second ? ' second' : ''}">
    <div class="ruler-element-card-label">${label}</div>
    <div class="ruler-element-card-tag">${elementSummary(el)}</div>
    <div class="ruler-element-card-dim">${dim}</div>
  </div>`;
}

function renderRulerFirstPicked(el) {
  rulerPanelBody.innerHTML =
    buildRulerCard(el, '1º Elemento', false) +
    `<p class="ruler-instructions">Agora clique no <strong>2º elemento</strong>.</p>`;
}

function computeRulerMeasurements(a, b) {
  const r = (n) => Math.round(n * 100) / 100;
  let gapH = (b.rect.left >= a.rect.right) ? b.rect.left - a.rect.right
           : (a.rect.left >= b.rect.right) ? a.rect.left - b.rect.right : 0;
  let gapV = (b.rect.top >= a.rect.bottom) ? b.rect.top - a.rect.bottom
           : (a.rect.top >= b.rect.bottom) ? a.rect.top - b.rect.bottom : 0;
  const dx = b.rect.centerX - a.rect.centerX;
  const dy = b.rect.centerY - a.rect.centerY;
  return {
    gapHorizontal: r(gapH), gapVertical: r(gapV),
    deltaLeft: r(b.rect.left - a.rect.left),
    deltaTop: r(b.rect.top - a.rect.top),
    deltaCenterX: r(dx), deltaCenterY: r(dy),
    distanceCenters: r(Math.sqrt(dx * dx + dy * dy)),
    widthA: r(a.rect.width), heightA: r(a.rect.height),
    widthB: r(b.rect.width), heightB: r(b.rect.height)
  };
}

function renderRulerResult(a, b, m) {
  const rows = [
    ['Gap Horizontal', `${m.gapHorizontal} px`],
    ['Gap Vertical', `${m.gapVertical} px`],
    ['Δ Left (B-A)', `${m.deltaLeft} px`],
    ['Δ Top (B-A)', `${m.deltaTop} px`],
    ['Distância centros', `${m.distanceCenters} px`],
    ['Δ centro X', `${m.deltaCenterX} px`],
    ['Δ centro Y', `${m.deltaCenterY} px`],
    ['Tamanho A', `${m.widthA} × ${m.heightA} px`],
    ['Tamanho B', `${m.widthB} × ${m.heightB} px`]
  ];
  const rowsHtml = rows.map(([l, v]) => `
    <div class="ruler-measure-row">
      <span class="ruler-measure-label">${l}</span>
      <span class="ruler-measure-value">${v}</span>
    </div>`).join('');
  rulerPanelBody.innerHTML =
    buildRulerCard(a, '1º Elemento (A)', false) +
    buildRulerCard(b, '2º Elemento (B)', true) +
    `<div class="ruler-measurements">
       <div class="ruler-measurements-title">📏 Medições</div>
       ${rowsHtml}
     </div>
     <div class="ruler-actions">
       <button class="ruler-action-btn copy" onclick="copyRulerWeb()">📋 Copiar</button>
       <button class="ruler-action-btn" onclick="resetRulerWeb()">🔄 Nova medição</button>
     </div>`;
  window.__lastRulerResult = { a, b, m };
}

window.copyRulerWeb = function() {
  const d = window.__lastRulerResult; if (!d) return;
  const { a, b, m } = d;
  const text = [
    '📐 Medição entre elementos',
    `A: <${a.tagName}>  ${a.cssPath}`,
    `B: <${b.tagName}>  ${b.cssPath}`, '',
    `Gap horizontal:    ${m.gapHorizontal} px`,
    `Gap vertical:      ${m.gapVertical} px`,
    `Δ left (B-A):      ${m.deltaLeft} px`,
    `Δ top  (B-A):      ${m.deltaTop} px`,
    `Distância centros: ${m.distanceCenters} px`,
    `Tamanho A:         ${m.widthA} × ${m.heightA} px`,
    `Tamanho B:         ${m.widthB} × ${m.heightB} px`
  ].join('\n');
  navigator.clipboard.writeText(text);
  logToConsole('📋 Medições copiadas', 'info');
};

window.resetRulerWeb = function() {
  rulerFirstElement = null;
  rulerPanelBody.innerHTML = `<p class="ruler-instructions">Clique no <strong>1º elemento</strong> no iframe.</p>`;
};

// ===== CONSOLE =====
toggleConsoleBtn.addEventListener('click', () => {
  const open = document.body.classList.toggle('console-open');
  toggleConsoleBtn.classList.toggle('active', open);
  toggleConsoleBtn.title = open ? 'Ocultar Developer Tools' : 'Mostrar Developer Tools';
});

clearConsole.addEventListener('click', () => {
  consoleContent.innerHTML = '';
  logToConsole('Console limpo', 'info');
});

function logToConsole(message, level = 'log') {
  const el = document.createElement('div');
  el.className = `console-message console-${level}`;
  const ts = new Date().toLocaleTimeString();
  el.innerHTML = `<span class="console-timestamp">[${ts}]</span><span class="console-text">${escapeHtml(message)}</span>`;
  consoleContent.appendChild(el);
  consoleContent.scrollTop = consoleContent.scrollHeight;
}

function escapeHtml(text) {
  if (text == null) return '';
  const div = document.createElement('div');
  div.textContent = String(text);
  return div.innerHTML;
}

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    if (rulerActive) deactivateRuler();
    else if (inspectorSidebar.classList.contains('open')) inspectorSidebar.classList.remove('open');
  }
});

logToConsole('Sistema iniciado 🚀', 'info');
logToConsole('⚠️ Em sites com X-Frame-Options o iframe pode não carregar. Use "HTML" para colar markup.', 'warn');
