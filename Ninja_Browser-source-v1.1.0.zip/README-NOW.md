





TO RUN:


npm i

npm audit fix --force


npm run dev -- --port=30xx










