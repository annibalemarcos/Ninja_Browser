# 🥷 Inspector Ninja Browser

Navegador leve com inspetor de elementos integrado, exportação em TXT e sistema de régua para medir distâncias entre elementos.

## ✨ Recursos

- 🔍 **Inspetor individual** (clique direito) — captura HTML, CSS path, XPath, classes, id, atributos.
- 🥷 **Element Inspector (botão)** — lista TODOS os elementos da página com CSS path e botão de copiar em cada um.
- 💾 **Salvar em TXT** — exporta toda a lista de elementos em arquivo `.txt`.
- 📐 **Régua** — mede distâncias e dimensões entre 2 elementos (clique direito em cada um após ativar).
- 📟 **Developer Tools (console)** — oculto por padrão, toggle pelo botão `📟`.

## 🚀 Como rodar (dev)

```bash
npm install
npm start         # ou: npm run dev
```

## 📦 Como gerar o `.exe` (Windows installer + portable)

No **Windows** (recomendado):

```bash
npm install
npm run build:win
```

Os artefatos saem em `dist/`:
- `Inspector Ninja Browser-1.1.0-x64.exe`     → instalador NSIS (com atalhos)
- `Inspector Ninja Browser-1.1.0-x64-portable.exe` → portátil (sem instalar)

Outros alvos:
```bash
npm run build:mac     # .dmg (rode no macOS)
npm run build:linux   # AppImage + .deb
```

> 💡 **Cross-build (Linux → Windows)** requer Wine instalado.
> No Windows, basta `npm run build:win`.

## 🌐 Versão Web

Está em `../Ninja_Browser_Web/` — basta abrir `index.html` em um navegador moderno.

Limitações da versão web:
- Sites com `X-Frame-Options: DENY/SAMEORIGIN` ou CSP `frame-ancestors` **não carregam** no iframe (limitação do navegador, não do app).
- Para esses sites, use o **botão "HTML"** e cole o markup que quer inspecionar.
- A versão `.exe` desktop não tem essa limitação.

## 🎯 Como usar

| Ação | Como fazer |
|---|---|
| Listar todos elementos | Clique em **🥷 Element Inspector** |
| Inspecionar um elemento | Clique direito no elemento |
| Medir entre 2 elementos | Clique em **📐**, depois clique direito no 1º elemento e no 2º |
| Mostrar/Ocultar console | Clique em **📟** |
| Salvar elementos em TXT | Lista de elementos → botão **💾 Salvar todos em TXT** |
| Fechar painéis | Tecla **Esc** |

---

Inspector Ninja Team 🥷
