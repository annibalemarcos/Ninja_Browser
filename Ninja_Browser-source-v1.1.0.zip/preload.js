const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  getWebviewInfo: () => ipcRenderer.invoke('get-webview-info'),
  
  copyToClipboard: (text) => {
    navigator.clipboard.writeText(text);
  }
});
